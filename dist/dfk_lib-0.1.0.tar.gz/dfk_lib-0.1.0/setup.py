# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dfk_lib',
 'dfk_lib.alchemist',
 'dfk_lib.auctions',
 'dfk_lib.auctions.hero',
 'dfk_lib.auctions.utils',
 'dfk_lib.consumable',
 'dfk_lib.dex',
 'dfk_lib.dex.utils',
 'dfk_lib.examples',
 'dfk_lib.genes',
 'dfk_lib.hero',
 'dfk_lib.hero.utils',
 'dfk_lib.land',
 'dfk_lib.land.utils',
 'dfk_lib.meditation',
 'dfk_lib.perilous_journey',
 'dfk_lib.quest',
 'dfk_lib.quest.utils',
 'dfk_lib.summoning']

package_data = \
{'': ['*']}

install_requires = \
['web3>=5.28.0,<6.0.0']

setup_kwargs = {
    'name': 'dfk-lib',
    'version': '0.1.0',
    'description': 'Toolbox to interact with the contracts of DefiKingdoms',
    'long_description': None,
    'author': '0rtis',
    'author_email': 'ortis@ortis.io',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
